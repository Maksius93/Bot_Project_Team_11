# Bot_Project_Team_11

Hello, this is a helper bot.
He knows how to add contacts with phone numbers, date of birth, notes (with hashtags) and carry out various manipulations with them.

Python must be installed on your PC to use


For install:
1. Downloads botik-0.1.zip (https://github.com/Maksius93/Bot_Project_Team_11)
2. Open cmd
3. Specify the path to the folder where the archive is located botik-0.1.zip ( like cd/name folder or C:\Users\User\Downloads)
4. Write comand:   pip install botik-0.1.zip
5. Once installed, type Hello

That's it, happy using


How to use the bot:
To add contacts type "add" and contact`s name after. 
You can also add phones (>5 digits each), birthdate (format like '27 August 1987' wo quotes), notes after name or leave these fields empty. 
You can also add phone number using this command after contact was created by it`s name. 
To change contact`s phone number type "change" and contact's name after, old phone you want to change and new phone (>5 digits) at the end.
To get contact's phone numbers type "phone" and contact`s name after.
To get contact's birthday type "bd" and contact`s name after.
To see all contacts with birthday in next n days from today, type "reminder n" (for example, 'reminder 0' wo quotes). You also`ll get contacts with bithday in next 7 days after the date you want to check.
To get all contacts in your notebook type "show all/show", to get n records, type "show n" wo quotes.
To delete contact type "delete" and contact`s name after.
To exit and save changes type "bye"/"close"/"exit"/"."  